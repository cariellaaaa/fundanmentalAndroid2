package com.example.androidfundamental1.util

class Constants {
    companion object{
        const val BASE_URL = "https://event-api.dicoding.dev/"
    }
}